
//RBE network
const char* ssid = "RBE";
const char* password = "elm69wisest16poisoned";
// robomqtt credientials
const char* mqtt_server = "robomqtt.cs.wpi.edu";
#define mqtt_port 1883
#define MQTT_USER "team11"
#define MQTT_PASSWORD "9nq43VU6cB6s"