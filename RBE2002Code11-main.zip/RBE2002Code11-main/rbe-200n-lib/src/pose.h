struct Pose
{
    float x;
    float y;
    float theta;
};